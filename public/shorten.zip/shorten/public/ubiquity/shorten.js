CmdUtils.CreateCommand({
  name: "shorten",
  icon: "http://is.gd/favicon.ico",
  homepage: "http://u.pilsch.com",
  author: { name: "Andrew Pilsch (based on code by Arun Shivaram)", email: "andrew@pilsch.com"},
  license: "GPL",
  description: "Shortens the selected URL using u.pilsch.com",
  help: "shorten <long url>",
  takes: {"longurl": noun_arb_text},
  preview: function( pblock, lurl ) {
       pblock.innerHTML = "Replaces the selected URL with a u.pilsch.com URL";
       this._shorturl(pblock,lurl,"preview");
  },
  execute: function(lurl) {
    this._shorturl("",lurl,"execute");
  },
  
  _shorturl: function( pblock,lurl,call){
    var baseUrl = "http://u.pilsch.com/api-create/" + lurl.text;
    //var params = {longurl: lurl.text};
	var params = {}
    jQuery.get( baseUrl, params,function(sUrl){
      if (call=="preview"){
        pblock.innerHTML = "Replaces the selected URL with "+sUrl;
      }
      if (call=="execute"){
        CmdUtils.setSelection(sUrl);
        CmdUtils.copyToClipboard(sUrl);
      }
    })
    
  }
  
});