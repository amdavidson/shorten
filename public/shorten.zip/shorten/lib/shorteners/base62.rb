class Base62
	@@base = 62
	
	def self.to_s(number)
		string = ""
		while number > (@@base - 1)
			place = number % @@base
			string = self.lookup(place) + string
			number = number / @@base	
		end
		
		self.lookup(number) + string
	end
	
	def self.to_i(string)
		number = 0
		i = string.length - 1
		string.each_byte do |c|
			c = c.chr
			if ("0".."9").member? c
				number += c.to_i * (@@base ** i)
			elsif ("a".."z").member? c
				first = "a"
				number += (c[0] - first[0] + 10) * (@@base ** i)
			else
				first = "A"
				number += (c[0] - first[0] + 36) * (@@base ** i)
			end
			i -= 1
		end
		number
	end
	
	def self.lookup(place)
		if (0..9).member? place
			string = "#{place}"
		elsif (10..35).member? place
			string = ("a".."z").to_a[place - 10]
		else
			string = ("A".."Z").to_a[place - 36]
		end
		
		string
	end
	
	def self.next_integer(integer)
		integer + 1
	end
end